<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        You are logged in!
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Admin: Show all Translation</h3>
				</div>
                <div class="panel-body">

				<table class="table table-striped">	
					<tr>
						<td>English Name</td>
						<td>Chinese Name</td>
						<td>Chinese Description</td>
					</tr>
						<?php foreach($menus as $menu): ?> 
					<tr>
						<td><?php echo e($menu->name); ?> </td> 
						<td><?php echo e($menu->name_cn); ?>  </td> 
						<td><?php echo e($menu->discription); ?>  </td>   
						<td>
							<a href="<?php echo e(URL::to('admin/translation-update', $menu->id)); ?>"> Update</a>
						</td>   	
					</tr> 		
						<?php endforeach; ?>	
				</table>


				<h1>English -> Chinese</h1>
				
				<?php if(count($errors) > 0): ?>
						<div class="">
							<ul>
								<?php foreach($errors->all() as $error): ?>
									<li><?php echo e($error); ?></li>
								<?php endforeach; ?>
							</ul>
						</div>
				<?php endif; ?>
					
					
				<form action="<?php echo e(url('admin/menu-chinese-form')); ?>" method="POST" >
					<?php echo csrf_field(); ?>

	
					<div class="form-group">
						<label for="enName">English Name</label>
						<input type="text" name="name" value="" class="form-control" />
					</div>
	
					<div class="form-group">
						<label for="cnName">Chinese Name</label>
						<input type="text" name="name_cn" value="" class="form-control"/>
					</div>	
	
					<div class="form-group">
						<label for="dicription">Dicription</label>
						<input type="text" name="discription" value="" class="form-control" />
					</div>	
					<input type="submit" name="submit" value="Add" class="btn btn-primary">
				</form>
				
                <a href="<?php echo e(URL::to('admin/menu-tanslateto-chinese')); ?>">View 没有翻译的菜名 / Update  </a>
				<a href="<?php echo e(URL::to('admin/translation-sentence-add')); ?>">食材整句输入</a>

				</div>
			</div>
 		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>