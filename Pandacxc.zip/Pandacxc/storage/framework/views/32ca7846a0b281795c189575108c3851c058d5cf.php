<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
					<h3 class="panel-title">Admin:  restaurant Menu Update</h3>
				</div>
                <div class="panel-body">


				<ul>
					<li><?php echo e($resturant->id); ?></li>
					<li>restaurant Name: <?php echo e($resturant->name); ?></li>
					<li>restaurant Type: <?php echo e($resturant->typeName); ?></li>
				</ul>


				<?php $cat = "" ?>
	
					<?php foreach($menus as $menu): ?> 
					
							<!-- Do not show category if catID is the same as the last one  -->
							<?php if( $cat != $menu->catID ): ?>		
							<h3>	<?php echo e($menu->catName); ?> </h3>
							<?php endif; ?>	 

		
							<p><?php echo e($menu->seq); ?>  <?php echo e($menu->name); ?> ( <?php echo e($menu->name_cn); ?>)  </p> 
							<p><?php echo e($menu->ingredients); ?>  </p>  
							<p><?php echo e($menu->ingredients_cn); ?></p>
							<a href="<?php echo e(URL::to('admin/restaurant-menu-delete', $menu->id)); ?>"> Delete Menu</a>
					
					   <?php	$cat = $menu->catID   ?>	
			 
					<?php endforeach; ?>	





				<h2>Menu Update: </h2>
				<a href="<?php echo e(URL::to('admin/menu-tanslate', $theResID )); ?>"> 初次翻译 </a>
				
				<form action="<?php echo e(url('admin/restaurant-menu-update/'.  $theResID )); ?>" method="POST" >
							 <?php echo csrf_field(); ?>

							 
						 
				<?php $cat = "" ?>
			
				<?php foreach($menus as $menu): ?> 
					<div class="form-group">
						<label for="sequence">Sequence No. </label>
						<input type="text" name="<?php echo e('seq_'. $menu->id); ?>" value=<?php echo e($menu->seq); ?> />
					</div>
					
				
					<!--Start: Course category-->
					<div class="form-group">
						<label for="catLabel">Course Category</label>
						<?php foreach( $allcats  as $cat ): ?>
					
							<!-- Set default value for category-->
							<?php if($cat->id == $menu->catID ): ?>
								<input type="radio" name=<?php echo e('catID_'. $menu->id); ?> value= <?php echo e($cat -> id); ?> checked /> <?php echo e($cat -> name); ?> 
							<?php else: ?>
								<input type="radio" name=<?php echo e('catID_'. $menu->id); ?> value= <?php echo e($cat -> id); ?> /> <?php echo e($cat -> name); ?> 
							<?php endif; ?> 
			
						 <?php endforeach; ?>
					</div>	 
					<!--End: Course category-->	 
					
					<div class="form-group">
						<label for="courseName">Course Name </label>
						<input type="text" name="<?php echo e('name_'. $menu->id); ?>" value="<?php echo e($menu->name); ?>"  class="form-control"  />
					</div> 

					<div class="form-group">
						<label for="courseName_cn">Course Name(Chinese) </label>
						<input type="text" name="<?php echo e('name_cn_'. $menu->id); ?>" value="<?php echo e($menu->name_cn); ?>"  class="form-control"  />
					</div> 


					<div class="form-group">
						<label for="ingredients">Ingredients / Descriptions</label>
						<input type="text" name="<?php echo e('ingredients_'. $menu->id); ?>" value="<?php echo e($menu->ingredients); ?>" class="form-control"  />
					</div> 
			
					<div class="form-group">
						<label for="ingredients_cn">Ingredients / Descriptions (Chinese)</label>
						<input type="text" name="<?php echo e('ingredients_cn_'. $menu->id); ?>" value="<?php echo e($menu->ingredients_cn); ?>" class="form-control"  />
					</div> 
			
			
					<div class="form-group">
						<label for="remarks">Remarks</label>
						<input type="text" name="<?php echo e('remarks_'. $menu->id); ?>" value="<?php echo e($menu->remarks); ?>" class="form-control"  />
					</div> 
					
				<hr> 
				<?php endforeach; ?>	


				<input type="submit" name="submit" value="Update">
	
				</form>

       
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>