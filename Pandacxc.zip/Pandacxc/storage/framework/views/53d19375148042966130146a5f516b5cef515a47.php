
<!doctype html>

<html lang="en">

<!--版头-->

<head>

	<meta charset="utf-8"> <!--utf-8是一种字符编码，除此之外在国内网站常用的还有GB2312和GBK。

	GB2312和GBK主要用于汉字编码，utf-8是国际编码，实用性比较强。-->

	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<meta name="viewport" content="width=device-width,initial-scal=1">

	<title>中文菜单翻译</title>	

	<link rel="stylesheet" href="css/bootstrap.min.css">

	<link href="css/menu.css" rel="stylesheet" type="text/css"/>



<!--device-width-->

</head>





<body>

<!--------------------------------------------搜索---------------------------------------->







	

<!-------------------------------------------城市级别-------------------------------------->

<ol class="breadcrumb">

  <li><a href="#">越南</a></li>

  <li><a href="#">会安</a></li>

  <li class="active">古镇外</li>

</ol>





<!---------------------------------------------餐厅----------------------------------------->

<div class="container">

	<div class="row">

		<?php foreach( $restaurants as $restaurant ): ?> 

		<div class="col-md-4">					

			<div class="outerbox2 country">	
				<a href="<?php echo e(URL::to( $restaurant -> id_url)); ?>">
				<!-- <a href="VietnamHoianPhi.html">  -->

					<div class="row">				

						<div class="pull-left col-xs-4 col-sm-2 col-md-4">						

							<img src="images/VietnamHoianPhi.jpg" alt="about" width="100" height="100">	

						</div>					

						<div class="restaurantInfo col-xs-8 col-sm-10 col-md-8">

							<dl>

								<dt class="redHeading text-capitalize"><?php echo e($restaurant -> name); ?> </dt>

								<dd class="text-capitalize"><small>Thái Phiên,Hội An,Việt Nam</small></dd>

								<dd><small>菜系：越式三文治</small></dd>

								<dd><small>营业时间：7：00am－8：00pm</small></dd>

							</dl>					

						</div>

					</div>

			 	</a>

			</div>

		</div>

	<?php endforeach; ?>	





















<!--<div class="row">

  <div class="col-sm-6 col-md-4">

    <div class="thumbnail">

      <img src="..." alt="...">

      <div class="caption">

        <h3>Thumbnail label</h3>

        <p>...</p>

        <p><a href="#" class="btn btn-primary" role="button">Button</a> <a href="#" class="btn btn-default" role="button">Button</a></p>

      </div>

    </div>

  </div>

</div>

--->





<!-- 如果要使用Bootstrap的js插件，必须先调入jQuery -->

<script src="http://libs.baidu.com/jquery/1.9.0/jquery.min.js"></script>

<!-- 包括所有bootstrap的js插件或者可以根据需要使用的js插件调用　-->

<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>                                              

</body>

</html>