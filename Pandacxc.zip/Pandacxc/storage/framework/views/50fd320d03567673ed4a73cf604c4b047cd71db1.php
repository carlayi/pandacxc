<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        You are logged in!
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Restaurants List</h3>
				</div>
                <div class="panel-body">
                    <ul>
                    	<?php foreach($restaurants as $restaurant): ?> 
						<ul>
							<li><?php echo e($restaurant->id); ?></li>
							<li>Restaurant Name: <?php echo e($restaurant->name); ?></li>
							<li>Restaurant Type: <?php echo e($restaurant->typeName); ?></li>
							<li>Address: <?php echo e($restaurant->address); ?> , <?php echo e($restaurant->city); ?> , <?php echo e($restaurant->country); ?></li>
							<li>Tel: <?php echo e($restaurant->tel); ?></li>
							
							
 						</ul>
                    
						<h4>操作</h4>
					  	<ul>
							<li>
								<a href="<?php echo e(URL::to('admin/restaurant-update', $restaurant->id)); ?>"> Update Restaurant Info</a>
							</li>
					 		<li>
								<a href="<?php echo e(URL::to('admin/restaurant-delete', $restaurant->id)); ?>"> Delete Restaurant</a>
							</li>
							
		
							<li>		 		
								<a href="<?php echo e(URL::to('admin/restaurant-menu-add', $restaurant->id)); ?>"> View / Add Menus </a>
							</li>
							<li>
								<a href="<?php echo e(URL::to('admin/restaurant-menu-update', $restaurant->id)); ?>"> Update Menus </a>
							</li>
						</ul>
					<hr>
					<?php endforeach; ?>	
					</ul>
				</div>
				</div>
				
			
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>