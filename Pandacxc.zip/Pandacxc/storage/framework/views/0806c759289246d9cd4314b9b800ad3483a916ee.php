<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-primary">
                <div class="panel-heading">
					<h3 class="panel-title">Restrants List</h3>
				</div>
                <div class="panel-body">
                
					<ul>
						<li><?php echo e($resturant->id); ?></li>
						<li>Restaurant Name: <?php echo e($resturant->name); ?></li>
						<li>Restaurant Type: <?php echo e($resturant->typeName); ?></li>
						<li>Restaurant Menu File: </li>
							<ul>
								<?php foreach($menuFiles as $menuFile): ?>
									<li><a href="<?php echo e(URL::to('admin/menufile', $menuFile->id)); ?>"> View Menu File - <?php echo e($menuFile -> id); ?> </a></li>
								<?php endforeach; ?>	
							</ul>
					</ul>
		
					<?php $cat = "" ?>
	
					<?php foreach($menus as $menu): ?> 
					
							<!-- Do not show category if catID is the same as the last one  -->
							<?php if( $cat != $menu->catID ): ?>		
							<h3>	<?php echo e($menu->catName); ?> </h3>
							<?php endif; ?>	 

		
							<p><?php echo e($menu->seq); ?>  <?php echo e($menu->name); ?>  </p> 
							<p><?php echo e($menu->ingredients); ?>  </p>  
							<p><?php echo e($menu->ingredients_cn); ?></p>
		
					
					   <?php	$cat = $menu->catID   ?>	
			 
					<?php endforeach; ?>	
				</div>	
			</div>

			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Add Menu</h3>
				</div>
				<div class="panel-body">

					<form action="<?php echo e(url('admin/restaurant-menu-add/'.  $theResID )); ?>" method="POST" >
							 <?php echo csrf_field(); ?>

						<div class="form-group">
							<label for="sequence">Sequence No. </label>
							<input type="text" name="seq" value="<?php echo e($seq); ?>" />
						</div>
					
		
					 
						<!--Course category-->
						<div class="form-group">
							<label for="catLabel">Course Category</label>
							<?php foreach( $allcats  as $cat ): ?>
							
								<!-- Set default value for category-->
								<?php if($cat->id == $defaultCatID ): ?>
									<input type="radio" name="catID" value= "<?php echo e($cat -> id); ?>" checked /> <?php echo e($cat -> name); ?> 
								<?php else: ?>
									<input type="radio" name="catID" value= "<?php echo e($cat -> id); ?>" /> <?php echo e($cat -> name); ?> 
								<?php endif; ?> 
		
							 <?php endforeach; ?>
						</div>	
					 
				
					
						<div class="form-group">
							<label for="course_name">Course Name</label>
							<input type="text" name="name" value=""  class="form-control">
						</div>
						
					
						<div class="form-group">
							<label for="ingredients">Ingredients / Descriptions </label>
							<input type="text" name="ingredients" value="" class="form-control" >
						</div>
				
						<div class="form-group">
							<label for="remarks">Remarks </label>
							<input type="text" name="remarks" value="" class="form-control" >
						</div>
						
				
						<input type="submit" name="submit" value="Add Menu">

					</form>
				
					<a href="<?php echo e(URL::to('admin/menu-tanslate', $resturant->id)); ?>"> 
					Empty Chinese translation => Add to 'Task Queue'
					</a>
				</div>
				
					
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>











<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>