<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Welcome to Administration Page</div>

				
				
                <div class="panel-body">
                    <p>You are logged in!</p>
                    <li>
                    <a href="<?php echo e(URL::to('admin/restaurant-add')); ?>"> View All Resturants / Add New Resturant </a>
                    </li>
                    
                    <li>
                    <a href="<?php echo e(URL::to('admin/new-restaurant')); ?>"> 餐厅老板更新的餐馆 </a>
                    </li>
                    
                    <li>
                    <a href="<?php echo e(URL::to('admin/menu-chinese-form')); ?>">所有中英对照食材 / Add New  </a>
                    </li>
                    
                    <li>
                    <a href="<?php echo e(URL::to('admin/menu-tanslateto-chinese')); ?>">没有翻译的食材 / Update  </a>
					</li>
					<li>
					<a href="<?php echo e(URL::to('admin/translation-sentence-add')); ?>">食材整句输入</a>
					</li>
					
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>