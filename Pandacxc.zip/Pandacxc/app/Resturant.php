<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Resturant extends Model
{
    //
   
   
  	 public static function ownerNewAddedRestaurants() {
   
   	 	$ownerNewAddedRestaurants = self::where('created_by','Owner') -> get();
        return $ownerNewAddedRestaurants;
    }
        
        
}
