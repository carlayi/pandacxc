<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menufile extends Model
{
    //
}
