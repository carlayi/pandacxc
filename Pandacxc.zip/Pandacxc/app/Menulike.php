<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menulike extends Model
{
    //
}
