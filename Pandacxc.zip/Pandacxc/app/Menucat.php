<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menucat extends Model
{
    //
}
