<?php
use App\Resturant;
use App\Category;

//use \DateTime;


/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/



Route::get('about', function()
{
    return 'ABOUT content';
});

  

    Route::get('/qrcode', function () {
        return view('QRtest');
    });
    
    
    Route::get('/test', function () {
    	
		$a = "ChiangMai";
		$a = str_replace(' ','-',$a);
   	 	return	strtolower( $a );

	
    });
  
// Users   
Route::get('/', function () {
        return view('Users.home');
});
 

// Restanrant
Route::get('en', function(){
	return view('Restaurant.home');
});
    
Route::get('restaurant-info-form', 'ResturantController@showUserResturantForm');
Route::post('restaurant-info-form','ResturantController@addResturantByResturant');
    
Route::get('{rstrUrl}/upload-menu', 'ResturantController@showUploadMenuForm');
Route::post('{rstrUrl}/upload-menu','ResturantMenuController@uploadFile');


Route::get('{rstrUrl}/qrcode', 'ResturantController@openQrcodeView');    
/*   

	Route::get('/', function () {
        return view('welcome');
    })->middleware('guest');
    
    
     
	Route::get('/admin',  ['middleware' => 'auth', function(){
		return View::make('Admin.Admin_Home');
	}]);

	Route::get('admin/restaurant-add', [
		'middleware' => 'auth',
		'uses' => 'ResturantController@showResturantForm' 
	]);
*/

Route::group(['middleware' => ['auth']], function () {

	Route::get('/admin', function(){
		return View::make('Admin.Admin_Home');
	});

	Route::get('admin/restaurant-add','ResturantController@showResturantForm');
	Route::post('admin/restaurant-add','ResturantController@addResturantByAdmin');

	Route::get('admin/new-restaurant','ResturantController@showOwnerAddedRestaurant');

	Route::get('admin/restaurant-update/{theResID}','ResturantController@findResturantToBeUpdate');
	Route::post('admin/restaurant-update/{theResID}','ResturantController@updateResturantByID');

	Route::get('admin/restaurant-delete/{theResID}', 'ResturantController@deleteResturantByID' );
	
	Route::get('admin/menufile/{fileID}', 'ResturantMenuController@indexMenuFile' );

	Route::get('admin/restaurant-menu-add/{theResID}','ResturantMenuController@displayResturantMenusForm');
	Route::post('admin/restaurant-menu-add/{theResID}','ResturantMenuController@uploadMenus');

	Route::get('admin/restaurant-menu-update/{theResID}','ResturantMenuController@openUpdateResturantMenuPage');
	Route::post('admin/restaurant-menu-update/{theResID}','ResturantMenuController@UpdateResturantMenuToDB');

	Route::get('admin/restaurant-menu-delete/{theMenuID}', 'ResturantMenuController@deleteMenuByID' );

	Route::get('admin/menu-tanslate/{theResID}','MenuCnController@translateWholeMenu');

	Route::get('admin/menu-tanslateto-chinese','MenuCnController@showEmptyChineseMenus');
	Route::post('admin/menu-tanslateto-chinese','MenuCnController@UpdateEmptyChineseMenus');

	Route::get('admin/menu-chinese-form','MenuCnController@showChineseMenus');
	Route::post('admin/menu-chinese-form','MenuCnController@addChineseMenus');

	Route::get('admin/translation-update/{theTranID}','MenuCnController@updateTranslationForm');
	Route::post('admin/translation-update/{theTranID}','MenuCnController@updateTranslationByID');
	
	Route::get('admin/translation-sentence-add','MenuCnController@sentenceTranslationForm');
	Route::post('admin/translation-sentence-add','MenuCnController@sentenceTranslation');
});

Route::auth();

/*
Route::get('/restaurants/{country}', 'ResturantController@showAllResturant');
Route::get('/restaurants/{country}/{city}', 'ResturantController@showAllResturant');
*/

//Route::get('/restaurants/{theResID}', 'ResturantMenuController@userResturantIndex');

Route::post('/restaurants/{theResID}/add-menu-like/{theMenuID}', 'ResturantMenuController@addMenuLike');

Route::get('/home', 'HomeController@index');


Route::get('{country}/{city}', 'ResturantController@cityRestaurantsIndex');
Route::get('{rstrUrl}', 'ResturantMenuController@userResturantIndexByUrl');
 
 
 