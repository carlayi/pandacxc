<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Resturant;
use App\Menu;
use App\Menucat;
use App\Menulike;
use App\Menufile;
use View;
use App\Http\Controllers\MenuCnController;

class ResturantMenuController extends Controller
{

/*
|--------------------------------------------------------------------------
| Get Resturant Infomation by resturnat ID
|--------------------------------------------------------------------------
|
|
*/
	
	public function getResturantInfo($theResID)
    {	
    
    //Find Resturant from database by ID
   	//$Resturant = NEW Resturant;
   	$Resturant = Resturant::where('id',$theResID)->first();
   	
	return $Resturant;
    
	}
/*
|--------------------------------------------------------------------------
| Get Resturant Infomation by resturnat ID
|--------------------------------------------------------------------------
|
|
*/	
	public function userResturantIndex($theResID)
    {	
    
    	return View::make('R_Menu', array( 
			//'theResID' => $theResID , 
			'resturant' => self::getResturantInfo($theResID) ,
			'menus'  => self::getResturantCnMenus($theResID), 
   
			));	
    
	}

/*
|--------------------------------------------------------------------------
| Get Resturant Infomation by resturnat id_url
|--------------------------------------------------------------------------
|
|
*/	
	public function userResturantIndexByUrl($url)
    {	
    	$restaurant = Resturant::where('id_url', $url) -> first();
    	
    	//
    	return View::make('Users/restaurant', array( 
			//'theResID' => $theResID , 
			'restaurant' => $restaurant ,
			'menus'  => self::getResturantCnMenus($restaurant -> id), 
   
			));	
    
	}
	
	
/*
|--------------------------------------------------------------------------
| Get Resturant Menus (all menus) by resturnat ID, display with sequence
|--------------------------------------------------------------------------
|
|
*/
	
	public function getResturantMenu($theResID)
	{
		
    $Menus = Menu::where('ResID',$theResID)
    			-> orderBy('seq','asc')
    			-> orderBy('catID','asc')
    			->get();
    
  	return $Menus;
  	
	}


/*
|--------------------------------------------------------------------------
| Get Resturant Category and Menus(both English and Chinese) by Resturant ID
|--------------------------------------------------------------------------
|
*/

	public function getResturantCnMenus($theResID)
	{
		//find English menus
    	$menus = self::getResturantMenu( $theResID);
    	
    	
    	foreach( $menus as $menu ){
			//get category name by category id
			$catSet = Menucat::where('id',$menu -> catID ) -> first() ;
			if($catSet != NULL){
				$catName = $catSet -> name . "<" . $catSet -> name_cn . ">" ;
			}
			$menu -> catName = $catName;
			
			//get chinese ingredients name. 
			//$menusplits = explode( ',', $menu->ingredients );
			//$menu -> ingredients_cn = MenuCnController::FindCnMenu($menusplits);
			
			//for assist translation
			//$menu -> t_name_cn = MenuCnController::sentenceTranslate( $menu -> name );
			//$menu -> t_ingredients_cn = MenuCnController::sentenceTranslate( $menu -> ingredients );
			
		}
		
		return $menus;		
    }			
	
	
/*
|--------------------------------------------------------------------------
| Open R_Menu view by restaurant id	 (view for user - no input form)
|--------------------------------------------------------------------------
|
*/	
/*	
	public function displayResturantMenus($theResID)
    {	

		return View::make('R_Menu', array( 
		'theResID' => $theResID , 
		'Resturant' => self::getResturantInfo($theResID) ,
		'menus'  => self::getResturantCnMenus($theResID), 
   
		));	
    
	}
*/
/*
|--------------------------------------------------------------------------
| Open R_Menu_Form view by restaurant id  (view for admin - with the input form)
|--------------------------------------------------------------------------
|
*/		

	public function displayResturantMenusForm($theResID)
    {	

    	//Find All category
   		$allcats = Menucat::all();

		return View::make('Admin.R_Menu_Form', array( 
			'theResID' 	=> $theResID , 
			'resturant' => self::getResturantInfo($theResID) ,
			'menus'  	=> self::getResturantCnMenus($theResID), 
			'menuFiles' => self::getMenuFile($theResID),
			
			
			//Values use in the Form
			'allcats'	=> $allcats,
			'seq' 		=> self::getNextMenuSeqNo($theResID) + 1 ,
			'defaultCatID' 	=> self::getDefaultCatID($theResID)
   		
		));	
    
	}

/*
|--------------------------------------------------------------------------
| Give a Resturant ID, 
| Return the last menu seqence no 
|--------------------------------------------------------------------------
|
*/	
	public function getNextMenuSeqNo($theResID)
    {
    	$seq = Menu::where('ResID',$theResID) ->max('seq');
		return  $seq;
    }	
    	
	public function getDefaultCatID($theResID)
	{
		$seq = self::getNextMenuSeqNo($theResID);
    	//Default value for next category
    	$lastMenu = Menu::where('ResID',$theResID) 
    				->Where('seq',$seq)
    				->first();
    	
    	if($lastMenu){
    		return $lastMenu -> catID;
    	}else{
    		return "";
    	}	
    	
	}



/*
|--------------------------------------------------------------------------
| Upload data from R_Menu_Form to databse 'menus'
|--------------------------------------------------------------------------
|
*/
	public function addMenus($request,$theResID)
    {
    	$Menu = NEW Menu;
		$Menu -> ResID		= $theResID; 
		$Menu -> seq 		= $request->input('seq');
		$Menu -> catID 		= $request->input('catID');  
		$Menu -> name 		= $request->input('name'); 
		$Menu -> ingredients = $request->input('ingredients'); 
	
		//$Menu -> name_cn 		= MenuCnController::sentenceTranslate( $request->input('name') );  
		//$Menu -> ingredients_cn = MenuCnController::sentenceTranslate( $request->input('ingredients')); 
			
		$Menu -> remark = $request->input('remarks'); 

		$Menu -> save();
    
    }


/*
|--------------------------------------------------------------------------
| Upload data from R_Menu_Form to databse 'menus'
| Add new Englishname and ingredients to 'menucn'
|--------------------------------------------------------------------------
|
*/
	public function uploadMenus(Request $request,$theResID)
    {	
    	
		self::addMenus($request,$theResID);
		MenuCnController::sentenceToTranslationDB( $request->input('name') );
		MenuCnController::sentenceToTranslationDB( $request->input('ingredients') );
		
	
		return redirect('admin/restaurant-menu-add/'. $theResID);
    }
    
 

/*
|--------------------------------------------------------------------------
| Open the View of update Resturant Menu
|--------------------------------------------------------------------------
|
*/
	public function openUpdateResturantMenuPage($theResID)
	{
		//Find All category
   		 $allcats = Menucat::all();
    
		return View::make('Admin.R_Menu_Update', array( 
		'theResID' => $theResID , 
		'resturant' => self::getResturantInfo($theResID) ,
		//'menus'  => self::getResturantMenu($theResID),
		'menus'  => self::getResturantCnMenus($theResID),
		 
		'allcats' => $allcats,
   
		));	
	
	}	   
	

	
/*
|--------------------------------------------------------------------------
| Resturant Menu Update to Database
|--------------------------------------------------------------------------
|
*/	
	public function UpdateResturantMenuToDB(Request $request, $theResID)
	{
		$Menus = Menu::where('ResID',$theResID) -> get();

    	foreach( $Menus as $Menu ){
    	
    		$Menu->seq 			=$request->input('seq_' . $Menu->id ) ;
    		$Menu->catID		=$request->input('catID_' . $Menu->id );
    		$Menu->name 		=$request->input('name_' . $Menu->id );
    		$Menu->name_cn 		=$request->input('name_cn_' . $Menu->id );
    		$Menu->ingredients	=$request->input('ingredients_' . $Menu->id );
    		$Menu->ingredients_cn =$request->input('ingredients_cn_' . $Menu->id );
    		
    		$Menu -> save();
    
    	}
    	
    	return redirect('admin/restaurant-menu-update/'.$theResID);
    	
	}	


/*
|--------------------------------------------------------------------------
|  Menu Like +1
|     --- Check the user IP has liked the menu before, like +1 if not
|--------------------------------------------------------------------------
|
*/	

	public function addMenuLike(Request $request, $theResID,$theMenuID){
		
		$menu = Menu::find($theMenuID);
		if( $menu ){
			//Check if the same user IP 'like' the menu before 
			$ipCheck = Menulike::where('menuID',$theMenuID)
							->where('userIP',$request -> ip() )
							->get();
			if ( $ipCheck -> isEmpty() ){
				$menu -> likes = $menu -> likes  + 1 ;
				$menu -> save();
				
				$newUserIP = NEW Menulike;
				$newUserIP -> menuID = $theMenuID;
				$newUserIP -> userIP = $request -> ip();
				$newUserIP -> save();
			} 				
		
			
		
		}
	
		return redirect('restaurants/'.$theResID);
	}
	
	
/*
|--------------------------------------------------------------------------
|  Handle resturant owner uploaded menu file and txt 
|--------------------------------------------------------------------------
|
*/		
	
	public function uploadFile(Request $request, $rstrUrl){
		//get restaurant id by url
		$restaurant = Resturant::where('id_url', $rstrUrl) ->first();
		
		
		
		if ($request->hasFile('file_upload')) {
			$file = $request -> file('file_upload');
		
			$menuFileName = $rstrUrl . '.' . $file -> getClientOriginalExtension()    ; 
	
			$destinationPath = public_path(). '/upload/menu/';
			
			
			if( $file -> move($destinationPath, $menuFileName ) ) {
			
				//update database
				$menuFile = new Menufile;
				$menuFile -> ResID =  $restaurant ->id;
				$menuFile -> fileName = $menuFileName; 
				$menuFile -> menuText = $request -> input('menuTxt') ;
				
				$menuFile -> save();
				//file extention
				//size
			
			
				return redirect( $rstrUrl . '/qrcode');
			}
			else{
				return "Error - File Move Failed";
			}
		}		
		else{
				return "Error - File Upload Failed";
			
		}
	}
	
	
/*
|--------------------------------------------------------------------------
|  Admin View: menu file page for one restaurant
|--------------------------------------------------------------------------
|
*/		
	public function getMenuFile($theResID){
		$menuFiles = Menufile::where('ResID',$theResID) -> get();
		return $menuFiles;
	}
	
	public function indexMenuFile($fileID){
		$menuFile = Menufile::where('id',$fileID) -> first();
		return View::make('Admin.Menu_File', array( 
			'menuFile' => $menuFile, 
   
			));	
	
	}

/*
|--------------------------------------------------------------------------
|  Admin View: delete one menu
|--------------------------------------------------------------------------
|
*/		
	public function deleteMenuByID($theMenuID){
	
		//get the resturant id before delete
		$menu = Menu::where('id',$theMenuID) -> first();
		$theResID = $menu -> ResID;
		
		//delete
		$menu -> delete();
		
		return redirect('admin/restaurant-menu-update/'. $theResID);
	}
	

	


	
	
}
