<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Contracts\Validation\Validator;

use App\Http\Requests;

use App\Resturant;
use App\Category;

use DateTime;

use View;


class ResturantController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
  
  /*
 	public function __construct()
    {
        $this->middleware('auth');
    }
*/

   //   NOT USE ANYMORE
   // List All Resturants
	public function showAllResturant()
    {
    	$resturants = Resturant::all();
    	
    	return View::make('R_Info', array('resturants' => $resturants ));
    	
	}

	public function getTypeName($restaurant)
    {
    	$catIDs = explode( ',', $restaurant -> type );
		$restaurant -> typeName = CategoryController::getCategoryNameByIDs($catIDs) ;	
    }	
	
	
//List All Resturants, then show the add resturant form
	public function showResturantForm()
    {
    	$restaurants = Resturant::all();

    	//get every restruant's type id, use id to get type name
    	foreach( $restaurants as $restaurant){
			//$catIDs = explode( ',', $resturant -> type );
			//$resturant -> typeName = CategoryController::getCategoryNameByIDs($catIDs) ;	
			self::getTypeName($restaurant);
    	}
    		
    	// Resturant types for selections in the form
    	$restaurantTypes = Category::where('type','resturantType') -> get();
    	
    	return View::make('Admin.R_Info_Form', array(
    		'restaurants' => $restaurants, 
    		'restaurantTypes' => $restaurantTypes
    	));
    	
	}




/*
|--------------------------------------------------------------------------
| Get Resturant Infomation by resturnat ID
|--------------------------------------------------------------------------
|
|
*/	
	public function showUserResturantForm()
    {
   
     	// Resturant types for selections in the form
    	$restaurantTypes = Category::where('type','resturantType') -> get();
    	
    	return View::make('Restaurant.Info_Form', array(
    		'restaurantTypes' => $restaurantTypes
    	));
    	
	}

	
	
	
//////// Added on 20/04/2016
// Delete Resturant by id, then back to the Resturant List
	public function deleteResturantByID($theResID)
	{
	
		$Resturants = Resturant::where('id',$theResID) -> delete();
		return redirect('admin/restaurant-add');
    	
    	
	}




//
	public function findResturantToBeUpdate($theResID)
	{
		//$theResID = $Resturant->id
		$resturant = Resturant::where('id',$theResID) -> first();
		
		// Resturant types for selections in the form
    	$resturantTypes = Category::where('type','resturantType') -> get();
		
		return View::make('Admin.R_Info_Update_Form', array(
				'resturant'		 => $resturant ,
				'resturantTypes' => $resturantTypes
		));
    	
	}
	
	public function updateResturantByID(Request $request,$theResID)
	{
		$this->validate($request, [
        'name' 		=> 'required|max:100',
        'address'	=> 'required|max:200',
        'tel'		=> 'required|max:30',
        'country'	=> 'required|max:30',
        'city'		=> 'required|max:50',
       
        
    	]);
    	
		$resturant = Resturant::find($theResID);
		
		$resturant->name    = $request->input('name');
		$resturant->address = $request->input('address');
		$resturant->tel     = $request->input('tel');
		$resturant->country = $request->input('country');
		$resturant->city    = $request->input('city');
		$resturant->type    = implode(",",$request->input('restaurantType'));
		
		$resturant->save();
		
		
		return redirect('admin/restaurant-add');
	}

/*
|--------------------------------------------------------------------------
| Validation For Resturant Info Form
|--------------------------------------------------------------------------
|
|
*/

	public function ValidationForResturantInfo(Request $request)
	{
	
	  	$this->validate($request, [
        'name' 		=> 'required|max:100',
        'address'	=> 'required|max:200',
        'tel'		=> 'required|max:30',
        'country'	=> 'required|max:30',
        'city'		=> 'required|max:50',
        'restaurantType'		=> 'required',
        
    	]);
    	  
    	  
     /*
		//Validate Input Data
		$validator = Validator::make($request->all(), [
        'name' 		=> 'required|max:30',
        'address'	=> 'required',
        'tel'		=> 'required',
        'country'	=> 'required',
        'city'		=> 'required',
        'type'		=> 'required',
   		]);
		
		if ($validator->fails()) {
        return redirect('Admin/Resturant-Info-Form')
            ->withInput()
            ->withErrors($validator);
    	}
	*/ 		
	}



/*
|--------------------------------------------------------------------------
| use country-city-number-name from form to generate a url for Restaurant
|--------------------------------------------------------------------------
|
|
*/
	public function generateRestaurantUrl(Request $request)
	{
		//get a random number related to datetime
		$now = new \DateTime();
		$a = 	$now -> getTimestamp();
		$a = 	strval($a);
   	 	$a =	substr($a,-4);
		
		$country = $request->input('country');
		$country = str_replace(' ','-', $country );
		$country = strtolower( $country ) ; 
		
		$city = $request->input('city');
		$city = str_replace(' ','-', $city );
		$city = strtolower( $city ) ; 
		
		$name = $request->input('name');
		$name = str_replace(' ','-', $name );
		$name = strtolower( $name ) ; 
		
		$strURL = $country. '-'.  $city . '-'. $a  . '-'. $name;
		
		return $strURL ;
	}
	
	
/*
|--------------------------------------------------------------------------
| Save Resturant Info to database
|--------------------------------------------------------------------------
|
|
*/

	public function addResturants(Request $request, $createdBy)
	{
		$now = new DateTime();
		
		//Validation Passed, SAVE DATA TO Database
		$Resturant = NEW Resturant;
		$Resturant->name    = $request->input('name');
		$Resturant->address = $request->input('address');
		$Resturant->tel     = $request->input('tel');
		$Resturant->country = $request->input('country');
		$Resturant->city    = $request->input('city');
		$Resturant->type    = implode(",",$request->input('restaurantType'));
		
		$Resturant->id_url  = self::generateRestaurantUrl($request) ;
		
		if( $createdBy == 'Admin'){
			$Resturant -> created_by = 'Admin';
		}else{
			$Resturant -> created_by = 'Owner';
		}
		
		$Resturant->save();
	
	
	}	


/*
|--------------------------------------------------------------------------
| admin submit Resturant Info
|--------------------------------------------------------------------------
|
|
*/
	public function addResturantByAdmin(Request $request)
	{
		self::ValidationForResturantInfo($request);
		self::addResturants($request,'Admin');
		
		return redirect('admin/restaurant-add');
	}
   
   
/*
|--------------------------------------------------------------------------
| resturant owner submit Resturant Info
|--------------------------------------------------------------------------
|
|
*/
	public function addResturantByResturant(Request $request)
	{
		self::ValidationForResturantInfo($request);
		self::addResturants($request,'Owner');
		$rstrUrl = self::generateRestaurantUrl($request);
		
		return redirect($rstrUrl.'/upload-menu');
	} 
   
/*
|--------------------------------------------------------------------------
| resturant owner upload menu file page
|--------------------------------------------------------------------------
|
|
*/  
  
  	public function showUploadMenuForm($rstrUrl)
  	{
  	
  		return View::make('Restaurant.Menu_Upload' , array(
				'rstrUrl'		 => $rstrUrl 
		));
  	
  	}
  
  
/*
|--------------------------------------------------------------------------
| Admin: view restaurant owner new added resturants and menu photos
|--------------------------------------------------------------------------
|
|
*/  
   
   public function showOwnerAddedRestaurant()
  	{
 
  		$restaurants = Resturant::ownerNewAddedRestaurants();
  		return View::make('Admin.R_Owner_NewAdded' , array(
				'restaurants'		 => $restaurants 
		));
  	
  	}
   
   
   
  /*
|--------------------------------------------------------------------------
| Admin: view restaurant owner new added resturants and menu photos
|--------------------------------------------------------------------------
|
|
*/  
   
   public function openQrcodeView($rstrUrl)
   {
   		$theUrl = "http://www.pandacxc.com/" . $rstrUrl;
   		
   		return View::make('Restaurant.QR' , array(
			'theUrl'		 => $theUrl 
		));
   
   
   }

  /*
|--------------------------------------------------------------------------
| User: List all restaurants in one city
|--------------------------------------------------------------------------
|
|
*/  
   
   public function cityRestaurantsIndex($country,$city)
   {	//e.g.  new-zealand ----> New Zealand
   		$country = ucwords( str_replace('-',' ',$country ) );
   		$city	 = ucwords( str_replace('-',' ',$city ) );
   		
   		$restaurants = Resturant::where('country',$country) 
   								->where('city',$city)
   								->get();
   								
   		return View::make('Users.city' , array(
			'restaurants'		 => $restaurants 
		));
   
   
   }
   
   


   
}
