<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Category;

class CategoryController extends Controller
{

	public Static function getCategoryNameByIDs($catIDs){
	
		$catList ="";
		foreach ($catIDs as $catID) {
		
					if( !empty($catID)  ){
						$catDataSet = Category::where('id',$catID ) -> first();
			
							if( !empty($catDataSet  -> name)  ){
									$catList = $catList . ',' . $catDataSet -> name;
							}
					}
			};
	
		//return value has ',' in the front, get rid of it
			$a = substr( $catList,1, -1 );
			$b = substr( $catList,-1 );
			$catList = $a . $b;
  
		return $catList;
	
	}
    
}
