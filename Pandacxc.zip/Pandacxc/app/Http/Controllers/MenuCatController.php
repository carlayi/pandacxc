<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use View;

class MenuCatController extends Controller
{
/*
|--------------------------------------------------------------------------
| Added on 11/04/2016
|
| Look up category by catID  
| Return category English name + Chinese name
|--------------------------------------------------------------------------
|
|
*/

	 public function FindCat($catID)
	{
		$catSet = Menucat::where('id',$catID ) -> first() ;
		$catName = $catSet -> name . "<" . $catSet -> name_cn . ">" ;
		return $catName;
	
	}
	
	
	
	
	
	
}
