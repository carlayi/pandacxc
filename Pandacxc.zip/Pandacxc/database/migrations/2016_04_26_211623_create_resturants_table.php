<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateResturantsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('resturants',function($table)
		{
			$table->increments('id');
			$table->string('name',30);
			$table->string('address',50);
			$table->string('tel',30);
			$table->string('country',20);
			$table->string('state',20);
			$table->string('city',20);	
			$table->string('type',50);	
			
			$table->timestamps();
		});
		
		
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('resturants');
    }
}
