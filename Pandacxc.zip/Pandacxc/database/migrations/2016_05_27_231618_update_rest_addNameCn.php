<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateRestAddNameCn extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('menus',function($table)
		{
			$table->string('name_cn',255);
			$table->string('ingredients_cn',255);
			$table->string('remark',255);
			$table->dropColumn('ingredients_id') ;
		});  
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
