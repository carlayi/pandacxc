<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMenuCatTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('menucats',function($thetable)
		{
			$thetable->increments('id');
			$thetable->string('name',30);
			$thetable->string('name_cn',30) ->nullable();
		
			$thetable->timestamps();
			
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('menucats');
    }
}
