<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateRestaurantAndMenus extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         Schema::table('resturants',function($table)
		{
			$table->dropColumn('state') ;
			$table->dropColumn('menu_format_type');
			$table->Integer('curMenuFileId');
		});
		
		
		 Schema::table('menus',function($table)
		{
			$table->Integer('menuFileId');
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
