<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMenufileDatabase extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
          Schema::create('menufiles',function($table)
		{
			$table->increments('id');
			$table->string('fileName',255);
			$table->string('type',100);
			$table->string('size',30);
			$table->longText('menuText');
			
			$table->timestamps();
		});
		
		
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
