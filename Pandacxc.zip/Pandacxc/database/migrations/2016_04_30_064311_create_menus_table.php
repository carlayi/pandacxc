<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMenusTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
     public function up()
    {
        Schema::create('menus',function($thetable)
		{
			$thetable->increments('id');
			$thetable->Integer('ResID');
			$thetable->Integer('seq');
			$thetable->Integer('catID');
			$thetable->string('name');
			$thetable->string('ingredients');
			$thetable->Integer('ingredients_id')->nullable();
			$thetable->timestamps();
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema:drop('menus');
    }
}
