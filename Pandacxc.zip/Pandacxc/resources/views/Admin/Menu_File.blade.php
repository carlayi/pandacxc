@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        You are logged in!
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Admin: Show all Translation</h3>
				</div>
                <div class="panel-body">



						<li>Menu in Text: <textarea  class="form-control" rows="30" >{{ $menuFile -> menuText }} </textarea></li>
						<li> <img src="{{ url('upload/menu/'. $menuFile->fileName  ) }}"  ></li>
									
									
									
				</div>
			</div>
 		</div>
    </div>
</div>
@endsection