@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Admin Page: restaurant update</h3>
				</div>
                <div class="panel-body">

					<li>{{ $resturant->id }}</li>
					<li> restaurant Name: {{$resturant->name }}</li>
					<li> restaurant Address:  {{ $resturant->address . ',' .  $resturant->city . ',' . $resturant->country }}</li>
					<li> restaurant Phone No.: {{$resturant->tel }}</li>

					<h1>restaurant Information Update</h1>


					@if (count($errors) > 0)
						<div class="">
							<ul>
								@foreach ($errors->all() as $error)
									<li>{{ $error }}</li>
								@endforeach
							</ul>
						</div>
					@endif



					<form action="{{ url('admin/restaurant-update/'.$resturant->id) }}" method="POST" >
						 {!! csrf_field() !!}
						<div class="form-group">
							<label for="name">restaurant Name</label>
							<input type="text" name="name" value="{{ $resturant->name }}" class="form-control"/>
						</div>
						
						<div class="form-group">
							<label for="country">restaurant Address</label>
							<br>
							Coutry: <input type="text" name="country" value="{{$resturant->country  }}"  class="form-control" />   
							City:   <input type="text" name="city"    value="{{ $resturant->city }}"  class="form-control" />  
							address:<input type="text" name="address" value="{{ $resturant->address }}"   class="form-control"/>   
						</div>
		
		
						<div class="form-group">
							<label for="tel">Returant Phone No.</label>
							<input type="text" name="tel" value="{{ $resturant->tel }}"  class="form-control"/> 
						</div>
						
						<div class="form-group">
							<label for="tel">restaurant Type</label>
							
							
							
								@foreach( $resturantTypes as $resturantType ) 
									<label class="checkbox-inline"> 	
									
										<!--checked the box for old value -->
										@if( in_array($resturantType ->id , explode(",", $resturant -> type) )   )	
											  <input type="checkbox" name="restaurantType[]" id={{ "restaurantType_" .  $resturantType ->id }} 
											  value={{ $resturantType ->id }} checked> 
											  {{ $resturantType ->name }}
											  
										@else
											 <input type="checkbox" name="restaurantType[]" id={{ "restaurantType_" .  $resturantType ->id }} 
											  value={{ $resturantType ->id }} > 
											  {{ $resturantType ->name }}
											  
										@endif	  
									</label>
 								@endforeach
							
							
							
						</div>
						
						<input type="submit" name="submit" value="Update restaurant"   class="btn btn-primary">
	

					</form>   

				</div>
			</div>
 		</div>
    </div>
</div>
@endsection