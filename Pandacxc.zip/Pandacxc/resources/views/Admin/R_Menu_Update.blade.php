@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
					<h3 class="panel-title">Admin:  restaurant Menu Update</h3>
				</div>
                <div class="panel-body">


				<ul>
					<li>{{ $resturant->id }}</li>
					<li>restaurant Name: {{$resturant->name }}</li>
					<li>restaurant Type: {{$resturant->typeName }}</li>
				</ul>


				<?php $cat = "" ?>
	
					@foreach ($menus as $menu) 
					
							<!-- Do not show category if catID is the same as the last one  -->
							@if( $cat != $menu->catID )		
							<h3>	{{ $menu->catName }} </h3>
							@endif	 

		
							<p>{{ $menu->seq }}  {{ $menu->name }} ( {{ $menu->name_cn}})  </p> 
							<p>{{ $menu->ingredients }}  </p>  
							<p>{{ $menu->ingredients_cn }}</p>
							<a href="{{ URL::to('admin/restaurant-menu-delete', $menu->id) }}"> Delete Menu</a>
					
					   <?php	$cat = $menu->catID   ?>	
			 
					@endforeach	





				<h2>Menu Update: </h2>
				<a href="{{ URL::to('admin/menu-tanslate', $theResID ) }}"> 初次翻译 </a>
				
				<form action="{{ url('admin/restaurant-menu-update/'.  $theResID ) }}" method="POST" >
							 {!! csrf_field() !!}
							 
						 
				<?php $cat = "" ?>
			
				@foreach ($menus as $menu) 
					<div class="form-group">
						<label for="sequence">Sequence No. </label>
						<input type="text" name="{{ 'seq_'. $menu->id }}" value={{ $menu->seq }} />
					</div>
					
				
					<!--Start: Course category-->
					<div class="form-group">
						<label for="catLabel">Course Category</label>
						@foreach( $allcats  as $cat )
					
							<!-- Set default value for category-->
							@if($cat->id == $menu->catID )
								<input type="radio" name={{'catID_'. $menu->id }} value= {{$cat -> id}} checked /> {{  $cat -> name }} 
							@else
								<input type="radio" name={{'catID_'. $menu->id }} value= {{$cat -> id}} /> {{  $cat -> name }} 
							@endif 
			
						 @endforeach
					</div>	 
					<!--End: Course category-->	 
					
					<div class="form-group">
						<label for="courseName">Course Name </label>
						<input type="text" name="{{ 'name_'. $menu->id }}" value="{{ $menu->name }}"  class="form-control"  />
					</div> 

					<div class="form-group">
						<label for="courseName_cn">Course Name(Chinese) </label>
						<input type="text" name="{{ 'name_cn_'. $menu->id }}" value="{{ $menu->name_cn }}"  class="form-control"  />
					</div> 


					<div class="form-group">
						<label for="ingredients">Ingredients / Descriptions</label>
						<input type="text" name="{{ 'ingredients_'. $menu->id }}" value="{{ $menu->ingredients }}" class="form-control"  />
					</div> 
			
					<div class="form-group">
						<label for="ingredients_cn">Ingredients / Descriptions (Chinese)</label>
						<input type="text" name="{{ 'ingredients_cn_'. $menu->id }}" value="{{ $menu->ingredients_cn }}" class="form-control"  />
					</div> 
			
			
					<div class="form-group">
						<label for="remarks">Remarks</label>
						<input type="text" name="{{ 'remarks_'. $menu->id }}" value="{{ $menu->remarks }}" class="form-control"  />
					</div> 
					
				<hr> 
				@endforeach	


				<input type="submit" name="submit" value="Update">
	
				</form>

       
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
