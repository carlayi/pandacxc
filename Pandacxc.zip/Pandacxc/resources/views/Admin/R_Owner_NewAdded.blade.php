@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
        You are logged in!
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Restaurants List</h3>
				</div>
                <div class="panel-body">
                    <ul>
                    	@foreach ($restaurants as $restaurant) 
						<ul>
							<li>{{ $restaurant->id }}</li>
							<li>Restaurant Name: {{$restaurant->name }}</li>
							<li>Restaurant Type: {{$restaurant->typeName }}</li>
							<li>Address: {{$restaurant->address }} , {{ $restaurant->city }} , {{ $restaurant->country }}</li>
							<li>Tel: {{ $restaurant->tel }}</li>
							
							
 						</ul>
                    
						<h4>操作</h4>
					  	<ul>
							<li>
								<a href="{{ URL::to('admin/restaurant-update', $restaurant->id) }}"> Update Restaurant Info</a>
							</li>
					 		<li>
								<a href="{{ URL::to('admin/restaurant-delete', $restaurant->id) }}"> Delete Restaurant</a>
							</li>
							
		
							<li>		 		
								<a href="{{ URL::to('admin/restaurant-menu-add', $restaurant->id) }}"> View / Add Menus </a>
							</li>
							<li>
								<a href="{{ URL::to('admin/restaurant-menu-update', $restaurant->id) }}"> Update Menus </a>
							</li>
						</ul>
					<hr>
					@endforeach	
					</ul>
				</div>
				</div>
				
			
            
        </div>
    </div>
</div>
@endsection





