@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
      
            <div class="panel panel-primary">
                
				<div class="panel-heading">
					<h3 class="panel-title">Admin: 显示没有翻译的食材</h3>
				</div>
                <div class="panel-body">
				
				<table class="table table-striped">	
					<tr>
						<td>English Name</td>
						<td>Chinese Name</td>
						<td>Chinese Description</td>
					</tr>
					<tr>
						<td>{{ $translation->name }} </td> 
						<td>{{ $translation->name_cn }}  </td> 
						<td>{{ $translation->discription }}  </td>   
					</tr>
				</table>
				
				@if (count($errors) > 0)
				<div class="">
				<ul>
				@foreach ($errors->all() as $error)
				<li>{{ $error }}</li>
				@endforeach
				</ul>
				</div>
				@endif
				
				<form action="{{ url('admin/translation-update/'.$translation -> id) }}" method="POST" >
					{!! csrf_field() !!}

					<div class="form-group">
					<label for="enName">English Name</label>
					<input type="text" name="name" value="{{ $translation -> name }}" class="form-control" />
					</div>

					<div class="form-group">
					<label for="cnName">Chinese Name</label>
					<input type="text" name="name_cn" value="{{ $translation -> name_cn }}" class="form-control"/>
					</div>

					<div class="form-group">
					<label for="dicription">Dicription</label>
					<input type="text" name="discription" value="{{ $translation -> discription }}" class="form-control" />
					</div>
					
					<input type="submit" name="submit" value="Update" class="btn btn-primary">
				</form>


				</div>
			</div>
 		</div>
    </div>
</div>
@endsection