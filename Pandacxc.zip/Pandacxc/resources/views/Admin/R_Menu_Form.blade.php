@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-primary">
                <div class="panel-heading">
					<h3 class="panel-title">Restrants List</h3>
				</div>
                <div class="panel-body">
                
					<ul>
						<li>{{ $resturant->id }}</li>
						<li>Restaurant Name: {{$resturant->name }}</li>
						<li>Restaurant Type: {{$resturant->typeName }}</li>
						<li>Restaurant Menu File: </li>
							<ul>
								@foreach ($menuFiles as $menuFile)
									<li><a href="{{ URL::to('admin/menufile', $menuFile->id) }}"> View Menu File - {{ $menuFile -> id}} </a></li>
								@endforeach	
							</ul>
					</ul>
		
					<?php $cat = "" ?>
	
					@foreach ($menus as $menu) 
					
							<!-- Do not show category if catID is the same as the last one  -->
							@if( $cat != $menu->catID )		
							<h3>	{{ $menu->catName }} </h3>
							@endif	 

		
							<p>{{ $menu->seq }}  {{ $menu->name }}  </p> 
							<p>{{ $menu->ingredients }}  </p>  
							<p>{{ $menu->ingredients_cn }}</p>
		
					
					   <?php	$cat = $menu->catID   ?>	
			 
					@endforeach	
				</div>	
			</div>

			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title">Add Menu</h3>
				</div>
				<div class="panel-body">

					<form action="{{ url('admin/restaurant-menu-add/'.  $theResID ) }}" method="POST" >
							 {!! csrf_field() !!}
						<div class="form-group">
							<label for="sequence">Sequence No. </label>
							<input type="text" name="seq" value="{{ $seq }}" />
						</div>
					
		
					 
						<!--Course category-->
						<div class="form-group">
							<label for="catLabel">Course Category</label>
							@foreach( $allcats  as $cat )
							
								<!-- Set default value for category-->
								@if($cat->id == $defaultCatID )
									<input type="radio" name="catID" value= "{{$cat -> id}}" checked /> {{  $cat -> name }} 
								@else
									<input type="radio" name="catID" value= "{{$cat -> id}}" /> {{  $cat -> name }} 
								@endif 
		
							 @endforeach
						</div>	
					 
				
					
						<div class="form-group">
							<label for="course_name">Course Name</label>
							<input type="text" name="name" value=""  class="form-control">
						</div>
						
					
						<div class="form-group">
							<label for="ingredients">Ingredients / Descriptions </label>
							<input type="text" name="ingredients" value="" class="form-control" >
						</div>
				
						<div class="form-group">
							<label for="remarks">Remarks </label>
							<input type="text" name="remarks" value="" class="form-control" >
						</div>
						
				
						<input type="submit" name="submit" value="Add Menu">

					</form>
				
					<a href="{{ URL::to('admin/menu-tanslate', $resturant->id) }}"> 
					Empty Chinese translation => Add to 'Task Queue'
					</a>
				</div>
				
					
                
                </div>
            </div>
        </div>
    </div>
</div>
@endsection










