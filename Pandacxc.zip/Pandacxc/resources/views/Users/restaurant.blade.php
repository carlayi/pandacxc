<!-- 
1. 修改css文件位置 <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
2. 修改like按钮<button type="submit" form="nameform" value="Submit" 
-->
<!doctype html>

<html lang="en">

<!--版头-->

<head>

	<meta charset="utf-8"> <!--utf-8是一种字符编码，除此之外在国内网站常用的还有GB2312和GBK。

	GB2312和GBK主要用于汉字编码，utf-8是国际编码，实用性比较强。-->

	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<meta name="viewport" content="width=device-width,initial-scal=1">

	<title>中文菜单翻译</title>	

	<link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
	 
 
	<link rel="stylesheet" type="text/css" href="{{ asset('css/menu.css') }}"/>



<!--device-width-->

</head>





<body>

<!--------------------------------------------header---------------------------------------->



<div class="container">



	<div class="bamboo">

	<img src="images/header_bamboo.png" class="img-responsive" alt="Responsive image">

	</div>



	<div class="panda">

	<img src="images/header_logo.gif" class="img-responsive center-block" alt="Responsive image">

	</div>



	<div class="redTap">

	<img src="images/header_more.png" class="img-responsive" alt="Responsive image">

	</div>	

</div>



	

<!-------------------------------------------盈利版头广告-------------------------------------->



<!-----------------------------------------餐厅名称和菜系分类--------------------------------->

<div class="container">

	<div class="restaurant">

		<ul >

			<li class="h5">餐厅：{{ $restaurant -> name }}</li>

			<li class="h5">菜系：美式</li>

		</ul>

	</div>

</div>

	<!--带阴影框架-->

	

<!----------------------------------------------菜单------------------------------------------>



<!------------响应式------------>

<div class="container">

	<!------------前菜------------>

	<div class="list-group outerbox">	

	<?php $cat = "" ?>
	@foreach ($menus as $menu) 
		<!-- Do not show category if catID is the same as the last one  -->
		@if( $cat != $menu->catID )
		<p class="category h4">{{ $menu->catName }}</p>	
		
		<!--白色线条-->
		<div class="whiteLine"></div>
		@endif	 
		

	
	

	<!------前菜1------>

		<!---菜名--->

		<a href="#" class="list-group-item">

			<div class="dishNameBox">

				<div class="dishNumber"><p>{{ $menu->seq }}</p></div>

				<div class="dishName"><p class="h5"> {{ $menu->name }} </p></div>

			</div>

			<!--材料翻译-->

			<div class="foodName">	

				<p><small>{{ $menu->ingredients_cn }}</small></p>

			</div>

		<!---附件--->

			<div >

				<!--like icon-->
				<form action="{{ url('/restaurants/'. $restaurant -> id .'/add-menu-like/'. $menu -> id) }}" method="POST" id="likeform" >
							 {!! csrf_field() !!}
					<input type="submit" name="submit" value="{{ 'Like '. $menu->likes }}"  class="btn btn-default">	 
							 
					<button type="submit" form="nameform" value="Submit" class="btn btn-default btn-xs likeNmessage" aria-label="Left Align">

						<span class="glyphicon glyphicon-heart-empty likeIcon" aria-hidden="true"><span class="badge">{{ $menu->likes }}</span></span>

					</button>
				</form>
 				
				
				

				<!--留言 icon-->
				
				<button type="button" class="btn btn-default btn-xs likeNmessage" aria-label="Left Align">

  					<span class="glyphicon glyphicon glyphicon-pencil" aria-hidden="true"><span class="badge">3</span></span>

				</button>

				<!--价钱-->

				<p class="pull-right"><i>$11</i></p>

			</div>

		</a>			

		<!--白色线条-->

		<div class="whiteLine"></div>			

		

	   
   	<?php	$cat = $menu->catID   ?>
     
	@endforeach	



		<!------------更多选择------------>		

		<button type="button" class="btn btn-default seeMore">

  			<span class="glyphicon glyphicon-menu-down" aria-hidden="true"></span>

		</button>



		

	</div>

	



	<!------------主菜------------>



			

	<!------------甜品------------>





</div>



<!-- 如果要使用Bootstrap的js插件，必须先调入jQuery -->

<script src="http://libs.baidu.com/jquery/1.9.0/jquery.min.js"></script>

<!-- 包括所有bootstrap的js插件或者可以根据需要使用的js插件调用　-->

<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script> 

</body>

</html>