
<!doctype html>

<html lang="en">

<!--版头-->

<head>

	<meta charset="utf-8"> <!--utf-8是一种字符编码，除此之外在国内网站常用的还有GB2312和GBK。

	GB2312和GBK主要用于汉字编码，utf-8是国际编码，实用性比较强。-->

	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<meta name="viewport" content="width=device-width,initial-scal=1">

	<title>中文菜单翻译</title>	

	<link rel="stylesheet" href="css/bootstrap.min.css">

	<link href="css/menu.css" rel="stylesheet" type="text/css"/>



<!--device-width-->

</head>





<body>

<!--------------------------------------------header---------------------------------------->



<div class="container">



	<div class="bamboo">

	<img src="images/header_bamboo.png" class="img-responsive" alt="Responsive image">

	</div>



	<div class="panda">

	<img src="images/header_logo.gif" class="img-responsive center-block" alt="Responsive image">

	</div>



</div>



	

<!-------------------------------------------版头广告-------------------------------------->

<div class="indexAds">

	<img src="images/index_ads.jpg" class="img-responsive center-block" alt="Responsive image">

</div>



<!---------------------------------------------泰国----------------------------------------->
<a href="{{ URL::to('/thailand/chiang-mai') }}">
<!-- <a href="VietnamHoianXxx.html"> -->

	<div class="container">

		<div class="outerbox country">

			<div class="row">

				<div class="pull-left col-xs-4 col-sm-2">

					<img src="images/VietnamHoian.jpg" alt="about" width="100" height="100">

				</div>

				<div class="countryText">

					<h4 class="redHeading"> 越南</h4>

					<p>河内 同海 会安 胡志明（西贡）</p>

				</div>

			</div>

		</div>

	</div>

</a>



<a href="xx/xx/">

	<div class="container">

		<div class="outerbox country">

			<div class="row">

				<div class="pull-left col-xs-4 col-sm-2">

					<img src="images/index_linkToV.jpg" alt="about" width="100" height="100">

				</div>

				<div class="countryText">

					<h4 class="redHeading"> 泰国</h4>

					<p>曼谷 清迈 普吉岛</p>

				</div>

			</div>

		</div>

	</div>

</a>



<a href="xx/xx/">

	<div class="container">

		<div class="outerbox country">

			<div class="row">

				<div class="pull-left col-xs-4 col-sm-2">

					<img src="images/index_linkToV.jpg" alt="about" width="100" height="100">

				</div>

				<div class="countryText">

					<h4 class="redHeading"> 新西兰</h4>

					<p>皇后镇</p>

				</div>

			</div>

		</div>

	</div>

</a>

<!----------------------------------------------越南------------------------------------------>



<!----------------------------------------------上传------------------------------------------>





<!-- 如果要使用Bootstrap的js插件，必须先调入jQuery -->

<script src="http://libs.baidu.com/jquery/1.9.0/jquery.min.js"></script>

<!-- 包括所有bootstrap的js插件或者可以根据需要使用的js插件调用　-->

<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>                                              

</body>

</html>